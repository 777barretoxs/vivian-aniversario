# Site de Aniversário - Instruções

## Arquivos criados:
- `index.html` - Página principal
- `style.css` - Estilos e design
- `script.js` - Interatividade e animações

## Para adicionar as fotos:
1. Renomeie suas fotos para: `foto1.jpg`, `foto2.jpg`, `foto3.jpg`
2. Coloque-as na mesma pasta do site
3. As fotos serão exibidas como slideshow de fundo

## Para adicionar a música:
1. Baixe a música "Romântico" de Henrique e Juliano
2. Converta para formato MP3 se necessário
3. Renomeie para `romantico.mp3`
4. Coloque na mesma pasta do site

## Recursos do site:
- Slideshow automático das fotos de fundo
- Controle de música (play/pause)
- Design responsivo (funciona em celular)
- Animações românticas (corações flutuantes)
- Efeito de digitação no título
- Overlay escuro para melhor legibilidade do texto

## Como testar:
Abra o arquivo `index.html` em qualquer navegador web.

